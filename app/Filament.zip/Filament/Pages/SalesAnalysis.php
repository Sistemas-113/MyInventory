<?php

namespace App\Filament\Pages;

use Filament\Pages\Page;
use Filament\Support\Components\ViewComponent;
use Filament\Widgets\StatsOverviewWidget\Card;
use Filament\Tables\Contracts\HasTable;
use Filament\Tables\Concerns\InteractsWithTable;
use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;
use Filament\Actions\Action;
use App\Exports\CreditSalesExport;
use App\Exports\CashSalesExport;
use App\Models\SaleDetail;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
use Filament\Support\Colors\Color;
use Illuminate\Database\Eloquent\Model;

class SalesAnalysis extends Page implements HasTable
{
    use InteractsWithTable;

    protected static ?string $navigationIcon = 'heroicon-o-chart-bar';
    protected static ?string $navigationLabel = 'Análisis de Ventas';
    protected static ?string $title = 'Análisis de Ventas';
    protected static ?string $navigationGroup = 'Reportes';

    protected function getHeaderActions(): array
    {
        return [
            Action::make('exportCreditSales')
                ->label('Ventas a Crédito')
                ->icon('heroicon-o-document-arrow-down')
                ->color('warning')
                ->action(fn () => Excel::download(
                    new CreditSalesExport(),
                    'ventas-credito-' . now()->format('Y-m-d') . '.xlsx'
                )),

            Action::make('exportCashSales')
                ->label('Ventas de Contado')
                ->icon('heroicon-o-document-arrow-down')
                ->color('success')
                ->action(fn () => Excel::download(
                    new CashSalesExport(),
                    'ventas-contado-' . now()->format('Y-m-d') . '.xlsx'
                )),
        ];
    }

    protected function getStats(): array
    {
        $totalSales = SaleDetail::sum(DB::raw('quantity * unit_price'));
        $totalCost = SaleDetail::sum(DB::raw('quantity * purchase_price'));
        $totalProfit = $totalSales - $totalCost;
        $profitMargin = $totalSales > 0 ? ($totalProfit / $totalSales) * 100 : 0;

        return [
            Card::make('Ventas Totales', '$ ' . number_format($totalSales, 0, ',', '.'))
                ->description('Total facturado')
                ->descriptionIcon('heroicon-m-banknotes')
                ->color('primary'),

            Card::make('Ganancia Total', '$ ' . number_format($totalProfit, 0, ',', '.'))
                ->description('Margen bruto')
                ->descriptionIcon('heroicon-m-arrow-trending-up')
                ->color('success'),

            Card::make('Margen Promedio', number_format($profitMargin, 1) . '%')
                ->description('Rentabilidad')
                ->descriptionIcon('heroicon-m-chart-bar')
                ->color('info'),
        ];
    }

    public function table(Table $table): Table
    {
        return $table
            ->query(
                SaleDetail::query()
                    ->select([
                        'id',
                        'product_name',
                        DB::raw('SUM(quantity) as total_quantity'),
                        DB::raw('SUM(quantity * unit_price) as total_sales'),
                        DB::raw('SUM(quantity * (unit_price - purchase_price)) as total_profit')
                    ])
                    ->groupBy('id', 'product_name')
                    ->orderByDesc('total_quantity')
                    ->limit(10)
            )
            ->columns([
                TextColumn::make('product_name')
                    ->label('Producto')
                    ->searchable()
                    ->sortable(),
                TextColumn::make('total_quantity')
                    ->label('Cantidad')
                    ->numeric()
                    ->sortable()
                    ->alignEnd(),
                TextColumn::make('total_sales')
                    ->label('Ventas')
                    ->money('COP')
                    ->sortable()
                    ->alignEnd(),
                TextColumn::make('total_profit')
                    ->label('Ganancia')
                    ->money('COP')
                    ->sortable()
                    ->alignEnd()
                    ->color('success'),
            ])
            ->recordUrl(null)
            ->paginated(false);
    }

    public function getTableRecordKey(Model $record): string
    {
        return (string) $record->id;
    }

    public function getViewData(): array
    {
        return [
            'stats' => $this->getStats(),
            'topProductsTable' => $this->table
        ];
    }

    protected static string $view = 'filament.pages.sales-analysis';
}
